<?php
/*
Plugin Name: Keira Core
Plugin URI: https://github.com/habibur899
Description: This is keira core plugin
Version: 1.0
Author: Habibur Rahman
Author URI: https://facebook.com/habibur5g
License: GPLv2 or later
Text Domain: keira
Domain Path: /languages/
 */
function keira_core_plugin() {
	load_plugin_textdomain( 'keira', false, plugin_dir_path( __FILE__ ) . '/languages' );
}

add_action( 'plugin_loaded', 'keira_core_plugin' );

// All Portfolio
function portfolio_cpt_register() {

	$labels = [
		"name" => __( "All Portfolio", "keira" ),
		"singular_name" => __( "Portfolio", "keira" ),
		"menu_name" => __( "Portfolios", "keira" ),
		"all_items" => __( "All Portfolio", "keira" ),
		"add_new" => __( "Add Portfolio", "keira" ),
		"add_new_item" => __( "Add New Portfolio", "keira" ),
		"edit_item" => __( "Edit Portfolio", "keira" ),
		"new_item" => __( "New Portfolio", "keira" ),
		"view_item" => __( "View Portfolio", "keira" ),
		"view_items" => __( "View Portfolios", "keira" ),
		"featured_image" => __( "Portfolio image", "keira" ),
		"set_featured_image" => __( "Add portfolio image", "keira" ),
		"remove_featured_image" => __( "Remove portfolio image", "keira" ),
		"use_featured_image" => __( "Use portfolio image", "keira" ),
	];

	$args = [
		"label" => __( "All Portfolio", "keira" ),
		"labels" => $labels,
		"description" => "Display your all portfolio",
		"public" => true,
		"publicly_queryable" => false,
		"show_ui" => true,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => true,
		"rewrite" => [ "slug" => "portfolio", "with_front" => true ],
		"query_var" => true,
		"menu_icon" => "dashicons-portfolio",
		"supports" => [ "title", "editor", "thumbnail" ],
		"taxonomies" => [ "portfolio_category" ],
		"show_in_graphql" => false,
	];

	register_post_type( "portfolio", $args );
}

add_action( 'init', 'portfolio_cpt_register' );


// Portfolio Categories
function portfolio_category_cpt_register() {

	$labels = [
		"name" => __( "Portfolio Categories", "keira" ),
		"singular_name" => __( "Portfolio Categorie", "keira" ),
		"add_new_item" => __( "Add portfolio category", "keira" ),
	];


	$args = [
		"label" => __( "Portfolio Categories", "keira" ),
		"labels" => $labels,
		"public" => true,
		"publicly_queryable" => false,
		"hierarchical" => true,
		"show_ui" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"query_var" => true,
		"rewrite" => [ 'slug' => 'portfolio_category', 'with_front' => true, ],
		"show_admin_column" => false,
		"show_in_rest" => true,
		"rest_base" => "portfolio_category",
		"rest_controller_class" => "WP_REST_Terms_Controller",
		"show_in_quick_edit" => false,
		"show_in_graphql" => false,
	];
	register_taxonomy( "portfolio_category", [ "portfolio" ], $args );
}
add_action( 'init', 'portfolio_category_cpt_register' );
