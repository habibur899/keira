<!--blog img area starts-->

<div class="blog-img-area">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2>Single Blog Page</h2>
				<div class="breadcrumb">
					<a href="index-2.html">Home</a> / <a href="index.php">Single Blog</a>
					<!--change the home redirection according to whichever demo you want to use. for instant if you use particle version then use index-particles.html-->
				</div>
			</div>
		</div>
	</div>
</div>

<!--blog img area ends-->